# English front

**ridely.**

**Next city. Good company.**
Ottawa–Gatineau ↔ Montréal–Longueuil
**Custom pickup & drop-off options**
Extra fee · Where available · Driver approval required.

**RIDERS · 2 FREE BOOKING CREDITS**
Ride fare is separate, paid to the driver in cash.
1 credit per accepted reservation.

**DRIVERS · $25 CAD BONUS***
Complete 3 qualifying trips with passengers.
Free pilot listings. Cash fares paid directly to you.

**Scan. Sign up. Join in.**
- Private boarding codes
- Share your itinerary

**ridely.ca** · support@ridely.ca
QR: https://ridely.ca/?lang=en

*18+. One $25 bonus per driver after 3 separate qualifying trips with passenger
confirmation. First 25 approved claims. Driver approval and review required.
Full terms in your account. One credit per accepted reservation; ride fare is not
included.

# Verso français

**ridely.**

**Prochaine ville. Bonne compagnie.**
Ottawa–Gatineau ↔ Montréal–Longueuil
**Prise en charge et dépose personnalisées**
Avec supplément · Selon disponibilité et accord du conducteur.

**PASSAGERS · 2 CRÉDITS OFFERTS**
Crédits de réservation. Trajet payé en espèces au conducteur.
1 crédit par réservation acceptée.

**CONDUCTEURS · PRIME DE 25 $ CA***
Effectuez 3 trajets admissibles avec des passagers.
Annonces gratuites au pilote. Trajets payés directement.

**Scannez. Inscrivez-vous.**
- Codes d’embarquement privés
- Partage de votre itinéraire

**ridely.ca** · support@ridely.ca
QR : https://ridely.ca/fr

*18 ans et +. Une prime de 25 $ par conducteur après 3 trajets distincts admissibles
confirmés par un passager. 25 premières demandes approuvées. Vérifications et examen
requis. Conditions au compte. Un crédit par réservation acceptée; le prix du trajet
n’est pas inclus.
